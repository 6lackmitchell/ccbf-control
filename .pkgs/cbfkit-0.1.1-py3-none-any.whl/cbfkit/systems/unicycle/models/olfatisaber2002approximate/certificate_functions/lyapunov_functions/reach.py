import jax.numpy as jnp
from jax import jit, jacfwd, jacrev

#! Circular Obstacle Avoidance
N = 3


@jit
def V(x, cx, cy, r):
    return (x[0] - cx) ** 2 + (x[1] - cy) ** 2 - r**2


@jit
def dVdx(x, cx, cy, r):
    return jacfwd(V)(x, cx, cy, r)


@jit
def d2Vdx2(x, cx, cy, r):
    return jacrev(jacfwd(V))(x, cx, cy, r)


R1 = 0.25
C1 = 2.0
C2 = 2.0
GAMMA1 = 0.5
GAMMA2 = 1.5


#! Accessible Objects
def lyapunov_functions(goal):
    return [lambda t, x: V(jnp.hstack([x, t]), goal[0], goal[1], R1)]


def lyapunov_jacobians(goal):
    return [lambda t, x: dVdx(jnp.hstack([x, t]), goal[0], goal[1], R1)[:N]]


def lyapunov_hessians(goal):
    return [lambda t, x: d2Vdx2(jnp.hstack([x, t]), goal[0], goal[1], R1)[:N, :N]]


def lyapunov_times(goal):
    return [lambda t, x: dVdx(jnp.hstack([x, t]), goal[0], goal[1], R1)[-1]]


def lyapunov_conditions():
    return [lambda V: -C1 * V**GAMMA1 - C2 * V**GAMMA2]


def fxt_lyapunov_funcs(goal):
    return lambda: (
        lyapunov_functions(goal),
        lyapunov_jacobians(goal),
        lyapunov_hessians(goal),
        lyapunov_times(goal),
        lyapunov_conditions(),
    )

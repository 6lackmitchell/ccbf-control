"""
docstring
"""
from .ellipsoidal_obstacle import obstacle_ca

"""
lyapunov_conditions.py

docstring
"""
from typing import Callable
from jax import lax, Array


def a_s() -> Callable[[Array], Array]:
    """Generates function for computing RHS of Lyapunov conditions for Exponential stability:

    Vdot <= 0

    Args:
        None

    Returns:
        Callable[[Array], Array]: AS Lyapunov conditions
    """
    return lambda V: 0.0


def e_s(c1: float) -> Callable[[Array], Array]:
    """Generates function for computing RHS of Lyapunov conditions for Exponential stability:

    Vdot <= -c1*V

    Args:
        c1 (float): convergence constant

    Returns:
        Callable[[Array], Array]: ES Lyapunov conditions
    """
    return lambda V: lax.cond(V > 0, lambda _fake: -c1 * V, lambda _fake: 0.0, 0)


def ft_s(c1: float, e1: float) -> Callable[[Array], Array]:
    """Generates function for computing RHS of Lyapunov conditions for FTS:

    Vdot <= -c1*V**e1

    Args:
        c1 (float): convergence constant
        e1 (float): exponential constant

    Returns:
        Callable[[Array], Array]: FTS Lyapunov conditions
    """
    return lambda V: lax.cond(V > 0, lambda _fake: -c1 * V**e1, lambda _fake: 0.0, 0)


def fxt_s(c1: float, c2: float, e1: float, e2: float) -> Callable[[Array], Array]:
    """Generates function for computing RHS of Lyapunov conditions for FxTS:

    Vdot <= -c1*V**e1 - c2*V**e2

    Args:
        c1 (float): convergence constant 1
        c2 (float): convergence constant 2
        e1 (float): exponential constant 1
        e2 (float): exponential constant 2

    Returns:
        Callable[[Array], Array]: FxTS Lyapunov conditions
    """
    return lambda V: lax.cond(
        V > 0, lambda _fake: -c1 * V**e1 - c2 * V**e2, lambda _fake: 0.0, 0
    )

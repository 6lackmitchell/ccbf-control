"""
stochastic_barrier.py

docstring
"""
from typing import Callable
from jax import Array


def right_hand_side(alpha: float, beta: float) -> Callable[[Array], Array]:
    """Generates function for computing RHS of barrier conditions for stochastic CBF:

    hdot <= -alpha*h + beta

    Args:
        None

    Returns:
        Callable[[Array], Array]: Zeroing CBF barrier conditions
    """
    assert alpha >= 0
    assert beta >= 0
    return lambda h: -alpha * h + beta

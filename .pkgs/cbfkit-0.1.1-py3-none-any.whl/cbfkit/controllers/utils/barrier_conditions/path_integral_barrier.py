"""
path_integral_barrier.py

docstring
"""
from typing import Callable
from jax import Array
import jax.numpy as jnp
from jax.scipy.special import erfinv


def right_hand_side(
    rho: float, gamma: float, eta: float, time_period: float
) -> Callable[[Array], Array]:
    """Generates function for computing RHS of barrier conditions for risk-aware path integral CBF:

    Lh <= 1 - gamma - sqrt(2 * T) * eta * erfinv(1 - rho) + integral

    where integral is the Lebesgue integral of the generator of h from 0 to the current time.

    Args:
        rho (float): tolerable risk of violating constraint
        gamma (float): maximum initial value h, i.e., sup_{x0 in X0}h(x0)
        eta (float): maximum value of dh/dx * sigma(x) in constraint set, i.e., sup_{x in S}||dh/dx * sigma(x)||
        time_period (float): length of time interval of system operation (in sec)

    Returns:
        Callable[[Array], Array]: Risk-Aware Path Integral CBF barrier condition
    """
    assert 0 < rho < 1
    assert gamma > 0
    assert eta > 0
    assert 0 < time_period < jnp.inf

    return lambda integral: 1 - gamma - jnp.sqrt(2 * time_period) * eta * erfinv(1 - rho) + integral

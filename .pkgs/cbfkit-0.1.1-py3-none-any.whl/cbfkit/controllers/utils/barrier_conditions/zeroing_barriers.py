"""
zeroing_barriers.py

docstring
"""
from typing import Callable
from jax import Array


def linear_class_k(alpha: float) -> Callable[[Array], Array]:
    """Generates function for computing RHS of barrier conditions for zeroing CBF:

    hdot >= -alpha*h

    Args:
        None

    Returns:
        Callable[[Array], Array]: Zeroing CBF barrier conditions
    """
    assert alpha >= 0
    return lambda h: alpha * h


def cubic_class_k(alpha: float) -> Callable[[Array], Array]:
    """Generates function for computing RHS of barrier conditions for zeroing CBF:

    hdot >= -alpha*h**3

    Args:
        None

    Returns:
        Callable[[Array], Array]: Zeroing CBF barrier conditions
    """
    assert alpha >= 0
    return lambda h: alpha * h**3


def generic_class_k(alpha: Callable[[Array], Array]) -> Callable[[Array], Array]:
    """Generates function for computing RHS of barrier conditions for zeroing CBF:

    hdot >= -alpha(h)

    Args:
        None

    Returns:
        Callable[[Array], Array]: Zeroing CBF barrier conditions
    """

    def func(h: Array) -> Array:
        """Computes value of composed generic class K function.

        Args:
            h (Array): CBF value

        Returns:
            Array: value of composed alpha(h)
        """
        return alpha(h)

    return func

"""
risk_aware_barrier.py

docstring
"""
from typing import Callable
from jax import Array

#! INCOMPLETE -- STILL NEED TO DERIVE CONDITIONS


def right_hand_side(rho: float, alpha: float) -> Callable[[Array], Array]:
    """Generates function for computing RHS of barrier conditions for stochastic CBF:

    hdot <= -alpha*h + beta

    Args:
        None

    Returns:
        Callable[[Array], Array]: Zeroing CBF barrier conditions
    """
    assert alpha >= 0
    assert 0 < rho < 1

    #! Define this quantity
    r = 0.0
    return lambda h: -alpha * h + r

import jax
import jax.numpy as jnp
from jax import jit, Array, lax, vmap
from typing import Tuple, Callable
from cbfkit.optimization.mpc import generate_mpc_solver_quadratic_cost_linear_dynamics
from cbfkit.utils.user_types import ControllerCallable, ControllerCallableReturns

jax.config.update("jax_enable_x64", True)


def dynamic_slice(arr, idx):
    def slice_fn(idx):
        idx = jnp.expand_dims(idx, axis=0).astype(int)
        return jnp.take(arr, idx, axis=1)

    return vmap(jit(slice_fn))(idx)


def linear_mpc(
    A: Array,
    B: Array,
    Q: Array,
    R: Array,
    waypoints: Tuple[Array, Array],
    horizon: float,
    dt: float,
) -> Callable[[float, Array], Tuple[Array, Array]]:
    """Computes solution to Linear MPC problem using jaxopt.OSQP"""
    # Number of timesteps to predict
    steps = int(horizon / dt)
    waypoints_jnp = jnp.array(waypoints)

    mpc_solver = generate_mpc_solver_quadratic_cost_linear_dynamics(A, B, Q, R, Q, steps)

    def update_waypoints(x: float) -> Array:
        nonlocal waypoints_jnp
        # # Calculate indices for waypoints (time-based)
        # widx = jnp.arange(t, t + horizon, dt)
        # widx = widx.astype(int)[: int(horizon / dt)]

        # State-based waypoint indices
        deviations = jnp.abs(waypoints_jnp - jnp.expand_dims(x[:2], axis=1))
        min_index = jnp.argmin(deviations)

        # Ensure that waypoint indices do not exceed size of waypoints_jnp
        widx = jnp.linspace(
            min_index,
            min_index + int(horizon / dt),
            int(horizon / dt) + 1,
        )

        return jnp.squeeze(dynamic_slice(waypoints_jnp, widx))

    @jit
    def solve_mpc(t: float, x: Array) -> Tuple[Array, Array]:
        # Calculate xd for all steps
        xd = update_waypoints(x).T
        xd_supp = jnp.zeros((len(x) - xd.shape[0], xd.shape[1]))
        xd = jnp.vstack([xd, xd_supp]).T
        concatenated_x_xd = jnp.vstack([jnp.expand_dims(x, axis=0), xd])

        xbar, ubar = mpc_solver(concatenated_x_xd)

        return ubar, xbar

    return solve_mpc


def linear_mpc_controller(
    A: Array,
    B: Array,
    Q: Array,
    R: Array,
    waypoints: Tuple[Array, Array],
    horizon: float,
    dt: float,
) -> ControllerCallable:
    """Linear MPC Controller"""
    generate_control = linear_mpc(A, B, Q, R, waypoints, horizon, dt)

    @jit
    def controller(t: float, x: Array) -> ControllerCallableReturns:
        """Generates control input for linear MPC control law."""
        ubar, xbar = generate_control(t, x)
        data = {"xn_full": xbar, "un_full": ubar}

        return ubar[0, :], data

    return controller

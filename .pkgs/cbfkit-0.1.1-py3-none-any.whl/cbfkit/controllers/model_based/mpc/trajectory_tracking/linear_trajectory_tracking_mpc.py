import jax.numpy as jnp
from jax import jit, Array
from typing import Tuple, Callable
from cbfkit.optimization.mpc import generate_solve_linear_mpc
from cbfkit.utils.user_types import ControllerCallable, ControllerCallableReturns


def linear_mpc(
    A: Array,
    B: Array,
    Q: Array,
    R: Array,
    waypoints: Tuple[Array, Array],
    horizon: float,
    dt: float,
) -> Callable[[float, Array], Tuple[Array, Array]]:
    """Computes solution to Linear MPC problem using jaxopt.OSQP"""
    # Number of timesteps to predict
    steps = int(horizon / dt)
    waypoints_jnp = jnp.array(waypoints)

    solve_mpc = generate_solve_linear_mpc(A, B, Q, R, Q, steps)

    @jit
    def solve_mpc(t: float, x: Array) -> Tuple[Array, Array]:
        # Calculate indices for waypoints
        widx = jnp.arange(t, t + horizon, dt)
        widx = widx.astype(int)[: int(horizon / dt)]

        # Calculate xd for all steps
        xd = waypoints_jnp[:, widx]
        xd_supp = jnp.zeros((len(x) - xd.shape[0], len(widx)))
        xd = jnp.vstack([xd, xd_supp])

        xbar, ubar = solve_mpc(x, xd)

        return ubar, xbar

    return solve_mpc


def linear_mpc_controller(
    A: Array,
    B: Array,
    Q: Array,
    R: Array,
    waypoints: Tuple[Array, Array],
    horizon: float,
    dt: float,
) -> ControllerCallable:
    """Linear MPC Controller"""
    generate_control = linear_mpc(A, B, Q, R, waypoints, horizon, dt)

    @jit
    def controller(t: float, x: Array) -> ControllerCallableReturns:
        """Generates control input for linear MPC control law."""
        ubar, xbar = generate_control(t, x)
        data = {"xn_full": xbar, "un_full": ubar}

        return ubar[0, :], data

    return controller

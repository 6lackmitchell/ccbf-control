"""
#! docstring
"""
from typing import Dict, Any
from jax import Array
from cbfkit.utils.user_types import (
    DynamicsCallable,
    CertificateCollection,
)


#! To Do: implement (after discovering theory)
####################################################################################################
### STOCHASTIC CLF: TBD #########################################################
def generate_compute_stochastic_clf_constraints(
    control_limits: Array,
    dyn_func: DynamicsCallable,
    barriers: CertificateCollection = ([], [], [], [], []),
    lyapunovs: CertificateCollection = ([], [], [], [], []),
    **kwargs: Dict[str, Any],
):
    """Placeholder. Theory still in development."""
    print(dyn_func)
    print(barriers)
    print(lyapunovs)
    print(control_limits)
    print(kwargs)
    return

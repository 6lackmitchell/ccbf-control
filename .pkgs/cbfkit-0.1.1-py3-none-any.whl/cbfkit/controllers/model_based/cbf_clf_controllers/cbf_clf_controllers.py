"""
cbf_clf_controllers.py


"""
from typing import Union, Dict, Any
import jax.numpy as jnp
from jax import Array, lax, jit

from cbfkit.utils.user_types import (
    CertificateCollection,
    ControllerCallable,
    ControllerCallableReturns,
    DynamicsCallable,
    State,
)
from cbfkit.optimization.quadratic_program import solve as solve_qp
from .generate_constraints import (
    generate_compute_input_constraints,
    generate_compute_cbf_clf_constraints,
    generate_compute_zeroing_cbf_constraints,
    generate_compute_vanilla_clf_constraints,
    generate_compute_robust_cbf_constraints,
    generate_compute_robust_clf_constraints,
    generate_compute_ra_cbf_constraints,
    generate_compute_ra_clf_constraints,
    generate_compute_ra_pi_cbf_constraints,
    generate_compute_ra_pi_clf_constraints,
    generate_compute_stochastic_cbf_constraints,
    generate_compute_stochastic_clf_constraints,
)


def generate_generator_cbf_clf_controller(
    generate_compute_cbf_constraints,
    generate_compute_clf_constraints,
):
    """_summary_

    Args:
        generate_compute_certificate_constraints (Callable[ [DynamicsCallable, CertificateCollection, CertificateCollection, Array], Callable[[float, Array], Tuple[Array, Array, bool]], ]): _description_
    """

    def generate_cbf_clf_controller(
        control_limits: Array,
        nominal_input: ControllerCallable,
        dynamics_func: DynamicsCallable,
        barriers: CertificateCollection = ([], [], [], [], []),
        lyapunovs: CertificateCollection = ([], [], [], [], []),
        p_mat: Union[Array, None] = None,
        **kwargs: Dict[str, Any],
    ) -> ControllerCallable:
        """
        Compute the solution to a control barrier function/control Lyapunov function based quadratic program seeking to minimize the deviation
        from some nominal input.

        Args:
        nominal_input: the function in charge of computing the nominal input
        dynamics_func: the dynamics function describing the system to be controlled.
        barrier_func: the barrier function which should be less than or equal to zero within a particular set.
        barrier_jacobian: the Jacobian of the barrier function.
        control_limits: denotes the maximum control input in magnitude (e.g., for a car it's acceleration and steering rate).
        Q: state-weight parameter in the QP.
        R: input-weight parameter in the QP.
        P: positive definite matrix to compute final cost

        Returns:
        u: Optimal control input
        """
        complete = False
        n_con = len(control_limits)

        if p_mat is None:
            if "tunable_class_k" not in kwargs:
                n_bfs = 0
            elif kwargs["tunable_class_k"]:
                b_funcs, _, _, _, _ = barriers
                n_bfs = len(b_funcs)
                control_limits = jnp.stack([control_limits, 100 * jnp.ones((n_bfs,))])

            if "relaxable_clf" not in kwargs:
                n_lfs = 0
            elif kwargs["relaxable_clf"]:
                l_funcs, _, _, _, _ = lyapunovs
                n_lfs = len(l_funcs)
                control_limits = jnp.stack([control_limits, 1e6 * jnp.ones((n_lfs,))])

            p_mat = jnp.diag(
                jnp.hstack([jnp.ones((n_con,)), 1e2 * jnp.ones((n_bfs,)), 1e2 * jnp.ones((n_lfs,))])
            )

        compute_input_constraints = generate_compute_input_constraints(control_limits)
        compute_cbf_clf_constraints = generate_compute_cbf_clf_constraints(
            generate_compute_cbf_constraints,
            generate_compute_clf_constraints,
            control_limits,
            dynamics_func,
            barriers,
            lyapunovs,
            **kwargs,
        )

        def controller(t: float, x: State) -> ControllerCallableReturns:
            """_summary_

            Args:
                t (float): _description_
                x (State): _description_

            Returns:
                ControllerCallableReturns: _description_
            """
            # Compute nominal control input
            u_nom, _ = nominal_input(t, x)

            return jittable_controller(t, x, u_nom)

        @jit
        def jittable_controller(t: float, x: State, u_nom: Array) -> ControllerCallableReturns:
            """_summary_

            Args:
                t (float): _description_
                x (State): _description_
                u_nom (Array): _description_

            Returns:
                ControllerCallableReturns: _description_
            """
            nonlocal complete

            if n_bfs > 0:
                u_nom = jnp.stack([u_nom, jnp.ones((n_bfs,))])
            if n_lfs > 0:
                u_nom = jnp.stack([u_nom, jnp.zeros((n_lfs,))])

            # Compute QP cost, constraint functions
            q_vec = jnp.expand_dims(jnp.matmul(-2 * p_mat, u_nom), axis=-1)
            g_mat_u, h_vec_u = compute_input_constraints(t, x)
            g_mat_c, h_vec_c, sub_data = compute_cbf_clf_constraints(t, x)
            if "complete" in sub_data:
                complete = sub_data["complete"]

            # Stack input and certificate function constraints
            g_mat = jnp.vstack([g_mat_u, g_mat_c])
            h_vec = jnp.expand_dims(jnp.hstack([h_vec_u, h_vec_c]), axis=-1)

            # Solve QP
            sol, status = solve_qp(p_mat, q_vec, g_mat, h_vec)
            u = lax.cond(
                status,
                lambda _fake: jnp.array(sol[:n_con]).reshape((n_con,)),
                lambda _fake: jnp.zeros((n_con,)),
                0,
            )

            # Saturate the solution if necessary
            u = jnp.clip(u, -control_limits[:n_con], control_limits[:n_con]).reshape((n_con,))

            if "ra_params" in kwargs:
                #! To Do: integrate RA-PI states
                pass

            error = lax.cond(status, lambda _fake: False, lambda _fake: True, 0)

            # logging data
            data = {
                "error": error,
                "complete": complete,
                "sol": jnp.array(sol),
                "u": u,
                "u_nom": u_nom,
                "sub_data": sub_data,
            }

            return u, data

        return controller

    return generate_cbf_clf_controller


####################################################################################################
### Controller Generators ##########################################################################
####################################################################################################

cbf_clf_controller = generate_generator_cbf_clf_controller(
    generate_compute_zeroing_cbf_constraints,
    generate_compute_vanilla_clf_constraints,
)
robust_cbf_clf_controller = generate_generator_cbf_clf_controller(
    generate_compute_robust_cbf_constraints,
    generate_compute_robust_clf_constraints,
)
ra_cbf_clf_controller = generate_generator_cbf_clf_controller(
    generate_compute_ra_cbf_constraints,
    generate_compute_ra_clf_constraints,
)
ra_pi_cbf_clf_controller = generate_generator_cbf_clf_controller(
    generate_compute_ra_pi_cbf_constraints,
    generate_compute_ra_pi_clf_constraints,
)
stochastic_cbf_clf_controller = generate_generator_cbf_clf_controller(
    generate_compute_stochastic_cbf_constraints,
    generate_compute_stochastic_clf_constraints,
)

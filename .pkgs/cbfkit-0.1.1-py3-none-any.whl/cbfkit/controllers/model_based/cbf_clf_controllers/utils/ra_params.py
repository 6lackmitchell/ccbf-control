"""
#! docstring
"""
from typing import Union, Optional, Callable
from jax import Array


class Params:
    """#! docstring"""

    integrator_states: Union[Array, None] = None

    def __init__(
        self,
        t_max: Optional[Union[float, None]] = None,
        p_bound: Optional[Union[float, None]] = None,
        gamma: Optional[Union[float, None]] = None,
        eta: Optional[Union[float, None]] = None,
        sigma: Optional[Union[Callable[[Array], Array], None]] = None,
        varsigma: Optional[Union[Callable[[Array], Array], None]] = None,
        epsilon: Optional[Union[float, None]] = 0.5,
        lambda_h: Optional[Union[float, None]] = 1.0,
    ):
        self.t_max = t_max
        self.p_bound = p_bound
        self.gamma = gamma
        self.eta = eta
        self.epsilon = epsilon
        self.lambda_h = lambda_h


class RiskAwareParams:
    """#! docstring"""

    def __init__(
        self,
        t_max: Optional[Union[float, None]] = None,
        p_bound_b: Optional[Union[float, None]] = None,
        gamma_b: Optional[Union[float, None]] = None,
        eta_b: Optional[Union[float, None]] = None,
        p_bound_v: Optional[Union[float, None]] = None,
        gamma_v: Optional[Union[float, None]] = None,
        eta_v: Optional[Union[float, None]] = None,
        sigma: Optional[Union[Callable[[Array], Array], None]] = None,
        varsigma: Optional[Union[Callable[[Array], Array], None]] = None,
    ):
        self.ra_cbf = Params(t_max, p_bound_b, gamma_b, eta_b)
        self.ra_clf = Params(t_max, p_bound_v, gamma_v, eta_v)

        self.sigma = sigma
        self.varsigma = varsigma

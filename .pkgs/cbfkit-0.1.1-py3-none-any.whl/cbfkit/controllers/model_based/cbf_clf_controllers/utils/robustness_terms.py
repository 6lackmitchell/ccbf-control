"""
#! docstring
"""
from typing import Callable
from jax import Array
import jax.numpy as jnp


def robustness_two_norm(bound: Array) -> Callable[[Array], Array]:
    """Compute robustness term (2-norm) in CBF condition.

    Args:
        bound (Array): upper bound on 2-norm of disturbance within operating domain

    Returns:
        Array: value of robustness term
    """

    def compute(jacobian: Array) -> Array:
        """Compute robustness term.

        Args:
            jacobian (Array): dhdx

        Returns:
            Array: value
        """
        return jnp.linalg.norm(jacobian) * bound

    return compute


def robustness_sup_norm(bound: Array) -> Array:
    """Compute robustness term (sup-norm) in CBF condition.

    Args:
        bound (Array): upper bound on sup-norm of disturbance within operating domain

    Returns:
        Array: value of robustness term
    """

    def compute(jacobian: Array) -> Array:
        """Compute robustness term.

        Args:
            jacobian (Array): dhdx

        Returns:
            Array: value
        """
        return jnp.sum(jnp.abs(jacobian * bound))

    return compute

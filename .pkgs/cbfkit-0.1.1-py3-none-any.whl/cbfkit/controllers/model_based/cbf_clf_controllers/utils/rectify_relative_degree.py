"""
#! docstring

Example
-------
def f(x):
    return jnp.array([x[2], x[3], x[4], x[5], 0, 0])

def g(_x):
    return jnp.array([[0, 0], [0, 0], [0, 0], [0, 0], [1, 0], [0, 1]])

def dynamics(x):
    return f(x), g(x), 1

def constraint(r1, r2):
    def h(x):
        return 1 - x[0] ** 2 - x[1] ** 2 - r1 - r2

    return h

r1, r2 = 0.1, 0.05

cbf = rectify_relative_degree(constraint(r1, r2), dynamics, 6)
print(cbf(jnp.array([0.5, 0.5, -0.1, 0, 0.2, 0])))
"""
from typing import Callable, Union, List, Tuple
from jax import random, jacfwd, jacrev, Array, jit
import jax.numpy as jnp
import jaxlib
import numpy as np
from cbfkit.controllers.utils.certificate_packager import certificate_package
from cbfkit.utils.user_types import DynamicsCallable, CertificateCollection

# For random sample generation
KEY = random.PRNGKey(0)
KEY, SUBKEY = random.split(KEY)


def rectify_relative_degree(
    function: Callable[[float, Array], Array],
    system_dynamics: DynamicsCallable,
    state_dim: int,
    form: str = "exponential",
) -> CertificateCollection:
    """Rectifies the relative degree of the provided constraint function with respect to
    the system dynamics deriving a new exponential- or high-order-CBF.

    Args:
        function (Callable[[float, Array], Array]): _description_
        system_dynamics (DynamicsCallable): _description_
        state_dim (int): _description_
        form (str, optional): _description_. Defaults to "exponential".

    Returns:
        Callable[[Array], Array]: _description_
    """
    function_list = compute_function_list(function, system_dynamics, state_dim, form)

    if form == "exponential":
        # Root locations in the left half-plane
        roots = jnp.array([-0.1 * (ii + 1) for ii in range(len(function_list))])

        # Calculate the polynomial coefficients using JAX and SciPy
        polynomial_coefficients = polynomial_coefficients_from_roots(roots)

        def cbf(x: Array) -> Array:
            return jnp.sum(
                jnp.array(
                    [func(x) * coeff for func, coeff in zip(function_list, polynomial_coefficients)]
                )
            )

    elif form == "high-order":

        def cbf(x: Array) -> Array:
            return function_list[0](x)

    return certificate_package(cbf, jit(jacfwd(cbf)), jit(jacrev(jacfwd(cbf))), state_dim)


def compute_function_list(
    function: Callable[[float, Array], Array],
    system_dynamics: DynamicsCallable,
    state_dim: int,
    form: str = "exponential",
    func_list: Union[List[Callable[[float, Array], Array]], None] = None,
    subkey: Union[jaxlib.xla_extension.ArrayImpl, None] = None,
    n_samples: int = 10,
):
    """Computes the cascading list of derivatives/functions for rectifying the relative
    degree of the provided function.

    Args:
        function (Callable[[float, Array], Array]): _description_
        system_dynamics (DynamicsCallable): _description_
        state_dim (int): _description_
        form (str, optional): _description_. Defaults to "exponential".
        func_list (Union[List[Callable[[float, Array], Array]], None], optional): _description_. Defaults to None.
        subkey (Union[jaxlib.xla_extension.ArrayImpl, None], optional): _description_. Defaults to None.
        n_samples (int, optional): _description_. Defaults to 10.

    Returns:
        List[Callable]: list of functions/derivatives
    """
    if func_list is None:
        func_list = []

    func_list.append(function)

    if subkey is None:
        subkey = SUBKEY
    else:
        _, subkey = random.split(KEY)

    # Do this at every level
    samples = random.normal(subkey, (n_samples, state_dim))
    jacobian = jacfwd(function)

    total = 0
    for sample in samples:
        _, dyn_g = system_dynamics(sample[:-1])
        grad = jacobian(sample)[:-1]
        total += jnp.sum(jnp.abs(jnp.matmul(grad, dyn_g)))

    def exponential_new_func(x: Array):
        return jnp.matmul(jacobian(x)[:-1], system_dynamics(x[:-1])[0])

    def highorder_new_func(x: Array):
        return jnp.matmul(jacobian(x)[:-1], system_dynamics(x[:-1])[0]) + function(x)

    if total == 0:
        if form == "exponential":
            new_func = exponential_new_func

        elif form == "high-order":
            new_func = highorder_new_func

        else:
            new_func = highorder_new_func

        return compute_function_list(
            new_func,
            system_dynamics,
            state_dim,
            form,
            func_list,
            subkey,
        )

    return func_list


def polynomial_coefficients_from_roots(roots: Array) -> Array:
    """Computes

    Args:
        roots (Array): roots of polynomial

    Returns:
        Array: polynomial coefficients
    """

    # Create a polynomial with roots at the specified locations
    polynomial = np.poly1d(roots, r=True)

    # Get the coefficients of the polynomial
    coefficients = jnp.array(polynomial.coeffs)

    return coefficients

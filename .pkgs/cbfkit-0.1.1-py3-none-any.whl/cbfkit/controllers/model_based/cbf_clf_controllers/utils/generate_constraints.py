import jax.numpy as jnp
from jax import Array, jit, lax, scipy
from typing import Callable, Tuple
from cbfkit.utils.user_types import (
    DynamicsCallable,
    BarrierCollectionCallable,
    PredictiveBarrierCollectionCallable,
    LyapunovCollectionCallable,
    State,
)
from .utils import block_diag_matrix_from_vec, interleave_arrays
from cbfkit.estimators.kalman_filters.ekf import get_global_k_ekf

###########################################################################
### Standard Constraints ##################################################
###########################################################################


def generate_compute_input_constraints(
    control_limits: Array = jnp.array([100.0, 100.0]),
) -> Callable[[float, State], Tuple[Array, Array]]:
    """docstring"""
    # Formulate the input constraints
    Acon = block_diag_matrix_from_vec(len(control_limits))
    bcon = interleave_arrays(control_limits, control_limits)

    @jit
    def compute_input_constraints(_t: float, _x: Array) -> Tuple[Array, Array]:
        """Computes input constraints."""
        return Acon, bcon

    return compute_input_constraints


def generate_compute_cbf_constraints(
    dynamics_func: DynamicsCallable,
    barriers: BarrierCollectionCallable = lambda: ([], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
    alpha: Array = jnp.array([1.0]),
) -> Callable[[float, State], Tuple[Array, Array]]:
    """docstring"""
    barrier_functions, barrier_jacobians, _, barrier_partials = barriers()

    M = len(control_limits)  # Extra 1 in case CLF relaxation
    L = len(barrier_functions)

    if len(alpha) != L:
        alpha = jnp.array(L * alpha.min())

    @jit
    def compute_cbf_constraints(t: float, x: State) -> Tuple[Array, Array]:
        """Computes CBF and CLF constraints."""
        dynamics_f, dynamics_g, _ = dynamics_func(x)

        # Formulate CBF constraint(s)
        # Acbf = jnp.zeros((L, M + K))  # Add 1 in case CLF relaxation
        Acbf = jnp.zeros((L, M))  # No CLF relaxation
        bcbf = jnp.zeros((L,))
        if L > 0:
            bf_x = jnp.stack([bf(t, x) for bf in barrier_functions])
            bj_x = jnp.stack([bj(t, x) for bj in barrier_jacobians])
            dbf_t = jnp.stack([bt(t, x) for bt in barrier_partials])

            Acbf = Acbf.at[:, :M].set(-jnp.matmul(bj_x, dynamics_g))
            bcbf = bcbf.at[:].set(
                dbf_t + jnp.matmul(bj_x, dynamics_f) + jnp.multiply(jnp.array(alpha), bf_x)
            )

        return Acbf, bcbf

    return compute_cbf_constraints


def generate_compute_clf_constraints(
    dynamics_func: DynamicsCallable,
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
) -> Callable[[float, State], Tuple[Array, Array, bool]]:
    """docstring"""
    lyapunov_functions, lyapunov_jacobians, _, lyapunov_partials, lyapunov_conditions = lyapunovs()

    M = len(control_limits)
    K = len(lyapunov_functions)
    complete = False

    # @jit
    def compute_clf_constraints(t: float, x: Array) -> Tuple[Array, Array, bool]:
        """Computes CBF and CLF constraints."""
        nonlocal complete
        dynamics_f, dynamics_g, _ = dynamics_func(x)

        # Formulate CLF constraint(s)
        # Aclf = jnp.zeros((K, M + K))  # Add 1 for CLF relaxation (in presence of CBFs)
        Aclf = jnp.zeros((K, M))  # No CLF relaxation
        bclf = jnp.zeros((K,))
        if K > 0:
            lf_x = jnp.stack([lf(t, x) for lf in lyapunov_functions])
            lj_x = jnp.stack([lj(t, x) for lj in lyapunov_jacobians])
            dlf_t = jnp.stack([lt(t, x) for lt in lyapunov_partials])
            lc_x = jnp.stack([lc(lf) for lc, lf in zip(lyapunov_conditions, lf_x)])

            Aclf = Aclf.at[:, :M].set(jnp.matmul(lj_x, dynamics_g))
            # Aclf = Aclf.at[:, M:].set(-jnp.ones((K,)))
            bclf = bclf.at[:].set(-dlf_t - jnp.matmul(lj_x, dynamics_f) + lc_x)
            print(f"V: {lf_x}")

            complete = False  # lax.cond(lf_x[0] < 0, lambda _fake: True, lambda _fake: False, 0)

        return Aclf, bclf, complete

    return compute_clf_constraints


def generate_compute_cbf_clf_constraints(
    dynamics_func: DynamicsCallable,
    barriers: BarrierCollectionCallable = lambda: ([], [], [], []),
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
    alpha: Array = jnp.array([1.0]),
):
    """_summary_

    Args:
        dynamics_func (DynamicsCallable): _description_
        barriers (_type_, optional): _description_. Defaults to lambda:([], [], [], []).
        lyapunovs (_type_, optional): _description_. Defaults to lambda:([], [], [], [], []).
        control_limits (Array, optional): _description_. Defaults to jnp.array([100.0, 100.0]).
        alpha (Array, optional): _description_. Defaults to jnp.array([1.0]).
    """
    compute_cbf_constraints = generate_compute_cbf_constraints(
        dynamics_func, barriers, control_limits, alpha
    )
    compute_clf_constraints = generate_compute_clf_constraints(
        dynamics_func, lyapunovs, control_limits
    )

    # @jit
    def compute_cbf_clf_constraints(t: float, x: Array):
        """_summary_

        Returns:
            _type_: _description_
        """
        Acbf, bcbf = compute_cbf_constraints(t, x)
        Aclf, bclf, complete = compute_clf_constraints(t, x)

        return jnp.vstack([Acbf, Aclf]), jnp.hstack([bcbf, bclf]), complete

    return compute_cbf_clf_constraints


###########################################################################
### Risk-Aware Constraints ##################################################
###########################################################################


def generate_compute_risk_aware_clf_constraints(
    ra_params: object,
    dynamics_func: DynamicsCallable,
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
) -> Callable[[float, State], Tuple[Array, Array, bool]]:
    """docstring"""
    (
        lyapunov_functions,
        lyapunov_jacobians,
        lyapunov_hessians,
        lyapunov_partials,
        lyapunov_conditions,
    ) = lyapunovs()

    M = len(control_limits)
    K = len(lyapunov_functions)
    r = float(
        jnp.sqrt(2 * ra_params.ra_clf.t_max)
        * ra_params.ra_clf.eta
        * scipy.special.erfinv(2 * ra_params.ra_clf.p_bound - 1)
    )
    complete = False

    # @jit
    def compute_clf_constraints(t: float, x: Array) -> Tuple[Array, Array, bool]:
        """Computes CBF and CLF constraints."""
        nonlocal complete, ra_params
        dynamics_f, dynamics_g, dynamics_s = dynamics_func(x)
        if t == 0:
            ra_params.ra_clf.integrator_states = jnp.zeros((K,))

        # Formulate CLF constraint(s)
        Aclf = jnp.zeros((K, M))  # No CLF relaxation
        bclf = jnp.zeros((K,))
        if K > 0:
            lj_x = jnp.stack([lj(t, x) for lj in lyapunov_jacobians])
            lh_x = jnp.stack([lh(t, x) for lh in lyapunov_hessians])
            dlf_t = jnp.stack([lt(t, x) for lt in lyapunov_partials])
            lf_x = jnp.stack([r + lf(t, x) for lf in lyapunov_functions])
            lc_x = jnp.stack([lc(lf) for lc, lf in zip(lyapunov_conditions, lf_x)])
            traces = jnp.array(
                [
                    0.5 * jnp.trace(jnp.matmul(jnp.matmul(dynamics_s.T, lh_ii), dynamics_s))
                    for lh_ii in lh_x
                ]
            )

            Aclf = Aclf.at[:, :M].set(jnp.matmul(lj_x, dynamics_g))
            bclf = bclf.at[:].set(-dlf_t - jnp.matmul(lj_x, dynamics_f) - traces + lc_x)

            complete = (
                False  # lax.cond(lf_x[0] - r < 0, lambda _fake: True, lambda _fake: False, 0)
            )

        return Aclf, bclf, complete

    return compute_clf_constraints


def generate_compute_risk_aware_cbf_clf_constraints(
    ra_params: object,
    dynamics_func: DynamicsCallable,
    barriers: BarrierCollectionCallable = lambda: ([], [], [], []),
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
    alpha: Array = jnp.array([1.0]),
):
    """_summary_

    Args:
        dynamics_func (DynamicsCallable): _description_
        barriers (_type_, optional): _description_. Defaults to lambda:([], [], [], []).
        lyapunovs (_type_, optional): _description_. Defaults to lambda:([], [], [], [], []).
        control_limits (Array, optional): _description_. Defaults to jnp.array([100.0, 100.0]).
        alpha (Array, optional): _description_. Defaults to jnp.array([1.0]).
    """
    compute_cbf_constraints = generate_compute_cbf_constraints(
        dynamics_func, barriers, control_limits, alpha
    )
    compute_clf_constraints = generate_compute_risk_aware_clf_constraints(
        ra_params, dynamics_func, lyapunovs, control_limits
    )

    # @jit
    def compute_cbf_clf_constraints(t: float, x: Array):
        """_summary_

        Returns:
            _type_: _description_
        """
        Acbf, bcbf = compute_cbf_constraints(t, x)
        Aclf, bclf, complete = compute_clf_constraints(t, x)

        return jnp.vstack([Acbf, Aclf]), jnp.hstack([bcbf, bclf]), complete

    return compute_cbf_clf_constraints


###########################################################################
### Risk-Aware Path Integral Constraints ##################################################
###########################################################################


def generate_compute_risk_aware_path_integral_clf_constraints(
    ra_params: object,
    dynamics_func: DynamicsCallable,
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
) -> Callable[[float, State], Tuple[Array, Array, bool]]:
    """docstring"""
    (
        lyapunov_functions,
        lyapunov_jacobians,
        lyapunov_hessians,
        lyapunov_partials,
        lyapunov_conditions,
    ) = lyapunovs()

    M = len(control_limits)
    K = len(lyapunov_functions)
    complete = False

    # @jit
    def compute_clf_constraints(t: float, x: Array) -> Tuple[Array, Array, bool]:
        """Computes CBF and CLF constraints."""
        nonlocal complete, ra_params
        dynamics_f, dynamics_g, dynamics_s = dynamics_func(x)
        if t == 0:
            ra_params.ra_clf.integrator_states = jnp.zeros((K,))

        # Formulate CLF constraint(s)
        Aclf = jnp.zeros((K, M))  # No CLF relaxation
        bclf = jnp.zeros((K,))
        lf_x = jnp.stack([lf(t, x) for lf in lyapunov_functions])
        lj_x = jnp.stack([lj(t, x) for lj in lyapunov_jacobians])
        lh_x = jnp.stack([lh(t, x) for lh in lyapunov_hessians])
        dlf_t = jnp.stack([lt(t, x) for lt in lyapunov_partials])
        w_vals = (
            ra_params.ra_clf.integrator_states
            + ra_params.ra_clf.gamma
            # + ra_params.ra_clf.eta
            + jnp.linalg.norm(jnp.matmul(lj_x, dynamics_s))
            * jnp.sqrt(2 * ra_params.ra_clf.t_max)
            * scipy.special.erfinv(ra_params.ra_clf.p_bound)
        )
        lc_x = jnp.stack([lc(w_vals[ii]) for ii, lc in enumerate(lyapunov_conditions)])
        traces = jnp.array(
            [
                0.5 * jnp.trace(jnp.matmul(jnp.matmul(dynamics_s.T, lh_ii), dynamics_s))
                for lh_ii in lh_x
            ]
        )

        Aclf = Aclf.at[:, :M].set(jnp.matmul(lj_x, dynamics_g))
        bclf = bclf.at[:].set(-dlf_t - jnp.matmul(lj_x, dynamics_f) - traces + lc_x)

        complete = False  # lax.cond(lf_x[0] < 0, lambda _fake: True, lambda _fake: False, 0)

        return Aclf, bclf, complete

    return compute_clf_constraints


def generate_compute_risk_aware_path_integral_cbf_clf_constraints(
    ra_params: object,
    dynamics_func: DynamicsCallable,
    barriers: BarrierCollectionCallable = lambda: ([], [], [], []),
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
    alpha: Array = jnp.array([1.0]),
):
    """_summary_

    Args:
        dynamics_func (DynamicsCallable): _description_
        barriers (_type_, optional): _description_. Defaults to lambda:([], [], [], []).
        lyapunovs (_type_, optional): _description_. Defaults to lambda:([], [], [], [], []).
        control_limits (Array, optional): _description_. Defaults to jnp.array([100.0, 100.0]).
        alpha (Array, optional): _description_. Defaults to jnp.array([1.0]).
    """
    compute_cbf_constraints = generate_compute_cbf_constraints(
        dynamics_func, barriers, control_limits, alpha
    )
    compute_clf_constraints = generate_compute_risk_aware_path_integral_clf_constraints(
        ra_params, dynamics_func, lyapunovs, control_limits
    )

    # @jit
    def compute_cbf_clf_constraints(t: float, x: Array):
        """_summary_

        Returns:
            _type_: _description_
        """
        Acbf, bcbf = compute_cbf_constraints(t, x)
        Aclf, bclf, complete = compute_clf_constraints(t, x)

        return jnp.vstack([Acbf, Aclf]), jnp.hstack([bcbf, bclf]), complete

    return compute_cbf_clf_constraints


###########################################################################
### ESTIMATED Risk-Aware Constraints ######################################
###########################################################################


def generate_compute_estimated_risk_aware_clf_constraints(
    ra_params: object,
    dynamics_func: DynamicsCallable,
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
) -> Callable[[float, State], Tuple[Array, Array, bool]]:
    """docstring"""
    (
        lyapunov_functions,
        lyapunov_jacobians,
        lyapunov_hessians,
        lyapunov_partials,
        lyapunov_conditions,
    ) = lyapunovs()

    M = len(control_limits)
    K = len(lyapunov_functions)
    r = float(
        jnp.sqrt(2 * ra_params.ra_clf.t_max)
        * ra_params.ra_clf.eta
        * scipy.special.erfinv(2 * ra_params.ra_clf.p_bound - 1)
    )
    complete = False

    # @jit
    def compute_clf_constraints(t: float, x: Array) -> Tuple[Array, Array, bool]:
        """Computes CBF and CLF constraints."""
        nonlocal complete, ra_params
        k_mat = get_global_k_ekf()
        dynamics_f, dynamics_g, dynamics_s = dynamics_func(x)
        if t == 0:
            ra_params.ra_clf.integrator_states = jnp.zeros((K,))

        # Formulate CLF constraint(s)
        Aclf = jnp.zeros((K, M))  # No CLF relaxation
        bclf = jnp.zeros((K,))
        if K > 0:
            lj_x = jnp.stack([lj(t, x) for lj in lyapunov_jacobians])
            lh_x = jnp.stack([lh(t, x) for lh in lyapunov_hessians])
            dlf_t = jnp.stack([lt(t, x) for lt in lyapunov_partials])
            lf_x = jnp.stack([r + lf(t, x) for lf in lyapunov_functions])
            lc_x = jnp.stack([lc(lf) for lc, lf in zip(lyapunov_conditions, lf_x)])
            lipschitz_term = (
                ra_params.ra_clf.lambda_h
                * ra_params.ra_clf.epsilon
                * jnp.linalg.norm(jnp.matmul(lj_x, k_mat))
            )
            varsigma_by_k = jnp.matmul(ra_params.ra_clf.varsigma, k_mat)
            traces = jnp.array(
                [
                    0.5 * jnp.trace(jnp.matmul(jnp.matmul(varsigma_by_k.T, lh_ii), varsigma_by_k))
                    for lh_ii in lh_x
                ]
            )
            extra_term = 0.0

            Aclf = Aclf.at[:, :M].set(jnp.matmul(lj_x, dynamics_g))
            bclf = bclf.at[:].set(
                -dlf_t - jnp.matmul(lj_x, dynamics_f) - traces - lipschitz_term - extra_term + lc_x
            )

            complete = (
                False  # lax.cond(lf_x[0] - r < 0, lambda _fake: True, lambda _fake: False, 0)
            )

        return Aclf, bclf, complete

    return compute_clf_constraints


def generate_compute_estimated_risk_aware_cbf_clf_constraints(
    ra_params: object,
    dynamics_func: DynamicsCallable,
    barriers: BarrierCollectionCallable = lambda: ([], [], [], []),
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
    alpha: Array = jnp.array([1.0]),
):
    """_summary_

    Args:
        dynamics_func (DynamicsCallable): _description_
        barriers (_type_, optional): _description_. Defaults to lambda:([], [], [], []).
        lyapunovs (_type_, optional): _description_. Defaults to lambda:([], [], [], [], []).
        control_limits (Array, optional): _description_. Defaults to jnp.array([100.0, 100.0]).
        alpha (Array, optional): _description_. Defaults to jnp.array([1.0]).
    """
    compute_cbf_constraints = generate_compute_cbf_constraints(
        dynamics_func, barriers, control_limits, alpha
    )
    compute_clf_constraints = generate_compute_estimated_risk_aware_clf_constraints(
        ra_params, dynamics_func, lyapunovs, control_limits
    )

    # @jit
    def compute_cbf_clf_constraints(t: float, x: Array):
        """_summary_

        Returns:
            _type_: _description_
        """
        Acbf, bcbf = compute_cbf_constraints(t, x)
        Aclf, bclf, complete = compute_clf_constraints(t, x)

        return jnp.vstack([Acbf, Aclf]), jnp.hstack([bcbf, bclf]), complete

    return compute_cbf_clf_constraints


###########################################################################
### Risk-Aware Path Integral Constraints ##################################################
###########################################################################


def generate_compute_estimated_risk_aware_path_integral_clf_constraints(
    ra_params: object,
    dynamics_func: DynamicsCallable,
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
) -> Callable[[float, State], Tuple[Array, Array, bool]]:
    """docstring"""
    (
        lyapunov_functions,
        lyapunov_jacobians,
        lyapunov_hessians,
        lyapunov_partials,
        lyapunov_conditions,
    ) = lyapunovs()

    M = len(control_limits)
    K = len(lyapunov_functions)
    complete = False

    # @jit
    def compute_clf_constraints(t: float, x: Array) -> Tuple[Array, Array, bool]:
        """Computes CBF and CLF constraints."""
        nonlocal complete, ra_params
        k_mat = get_global_k_ekf()
        dynamics_f, dynamics_g, dynamics_s = dynamics_func(x)
        if t == 0:
            ra_params.ra_clf.integrator_states = jnp.zeros((K,))

        # Formulate CLF constraint(s)
        Aclf = jnp.zeros((K, M))  # No CLF relaxation
        bclf = jnp.zeros((K,))
        lf_x = jnp.stack([lf(t, x) for lf in lyapunov_functions])
        lj_x = jnp.stack([lj(t, x) for lj in lyapunov_jacobians])
        lh_x = jnp.stack([lh(t, x) for lh in lyapunov_hessians])
        lipschitz_term = (
            ra_params.ra_clf.lambda_h
            * ra_params.ra_clf.epsilon
            * jnp.linalg.norm(jnp.matmul(lj_x, k_mat))
        )
        varsigma_by_k = jnp.matmul(ra_params.ra_clf.varsigma, k_mat)
        traces = jnp.array(
            [
                0.5 * jnp.trace(jnp.matmul(jnp.matmul(varsigma_by_k.T, lh_ii), varsigma_by_k))
                for lh_ii in lh_x
            ]
        )
        dlf_t = jnp.stack([lt(t, x) for lt in lyapunov_partials])
        w_vals = (
            ra_params.ra_clf.integrator_states
            + ra_params.ra_clf.gamma
            + ra_params.ra_clf.eta
            * jnp.sqrt(2 * ra_params.ra_clf.t_max)
            * scipy.special.erfinv(ra_params.ra_clf.p_bound)
        )
        lc_x = jnp.stack([lc(w_vals[ii]) for ii, lc in enumerate(lyapunov_conditions)])
        extra_term = 1000.0

        Aclf = Aclf.at[:, :M].set(jnp.matmul(lj_x, dynamics_g))
        bclf = bclf.at[:].set(
            -dlf_t - jnp.matmul(lj_x, dynamics_f) - traces - lipschitz_term - extra_term + lc_x
        )

        complete = False  # lax.cond(lf_x[0] < 0, lambda _fake: True, lambda _fake: False, 0)

        return Aclf, bclf, complete

    return compute_clf_constraints


def generate_compute_estimated_risk_aware_path_integral_cbf_clf_constraints(
    ra_params: object,
    dynamics_func: DynamicsCallable,
    barriers: BarrierCollectionCallable = lambda: ([], [], [], []),
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
    alpha: Array = jnp.array([1.0]),
):
    """_summary_

    Args:
        dynamics_func (DynamicsCallable): _description_
        barriers (_type_, optional): _description_. Defaults to lambda:([], [], [], []).
        lyapunovs (_type_, optional): _description_. Defaults to lambda:([], [], [], [], []).
        control_limits (Array, optional): _description_. Defaults to jnp.array([100.0, 100.0]).
        alpha (Array, optional): _description_. Defaults to jnp.array([1.0]).
    """
    compute_cbf_constraints = generate_compute_cbf_constraints(
        dynamics_func, barriers, control_limits, alpha
    )
    compute_clf_constraints = generate_compute_estimated_risk_aware_path_integral_clf_constraints(
        ra_params, dynamics_func, lyapunovs, control_limits
    )

    # @jit
    def compute_cbf_clf_constraints(t: float, x: Array):
        """_summary_

        Returns:
            _type_: _description_
        """
        Acbf, bcbf = compute_cbf_constraints(t, x)
        Aclf, bclf, complete = compute_clf_constraints(t, x)

        return jnp.vstack([Acbf, Aclf]), jnp.hstack([bcbf, bclf]), complete

    return compute_cbf_clf_constraints


###########################################################################
### Predictive Constraints ################################################
###########################################################################


def generate_compute_predictive_cbf_constraints(
    dynamics_func: DynamicsCallable,
    barriers: PredictiveBarrierCollectionCallable = lambda: ([], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
    alpha: Array = jnp.array([1.0]),
) -> Callable[[float, State], Tuple[Array, Array]]:
    """docstring"""
    barrier_functions, barrier_jacobians, _, barrier_partials = barriers()

    M = len(control_limits)
    L = len(barrier_functions)

    if len(alpha) != L:
        alpha = jnp.array(L * alpha.min())

    @jit
    def compute_predictive_cbf_constraints(t: float, x: Array, xbar: Array) -> Tuple[Array, Array]:
        """Computes CBF and CLF constraints."""
        dynamics_f, dynamics_g, _ = dynamics_func(x)

        # Formulate CBF constraint(s)
        Acbf = jnp.zeros((L, M))
        bcbf = jnp.zeros((L,))
        if L > 0:
            bf_x = jnp.stack([bf(t, x, xbar) for bf in barrier_functions])
            bj_x = jnp.stack([bj(t, x, xbar) for bj in barrier_jacobians])
            dbf_t = jnp.stack([bt(t, x, xbar) for bt in barrier_partials])

            Acbf = Acbf.at[:, :].set(-jnp.matmul(bj_x, dynamics_g))
            bcbf = bcbf.at[:].set(
                dbf_t + jnp.matmul(bj_x, dynamics_f) + jnp.multiply(jnp.array(alpha), bf_x)
            )

        return Aclf, bclf

    return compute_predictive_cbf_constraints


###########################################################################
### Adaptive Constraints ##################################################
###########################################################################


def generate_compute_adaptive_cbf_clf_constraints_fcn(
    dynamics_func: DynamicsCallable,
    barriers: BarrierCollectionCallable = lambda: ([], [], [], []),
    lyapunovs: LyapunovCollectionCallable = lambda: ([], [], [], [], []),
    control_limits: Array = jnp.array([100.0, 100.0]),
    alpha: Array = jnp.array([1.0]),
) -> Callable[[float, State], Tuple[Array, Array]]:
    """docstring"""
    barrier_functions, barrier_jacobians, _, barrier_partials = barriers()
    lyapunov_functions, lyapunov_jacobians, _, lyapunov_partials, lyapunov_conditions = lyapunovs()

    M = len(control_limits)
    L = len(barrier_functions)
    K = len(lyapunov_functions)

    # Formulate the input constraints
    alpha_limit = 100
    delta_limit = 1000
    upper_limits = jnp.hstack(
        [control_limits, jnp.array(L * [alpha_limit]), jnp.array(K * [delta_limit])]
    )
    lower_limits = jnp.hstack([control_limits, jnp.array(L * [0]), jnp.array(K * [0])])
    Au = block_diag_matrix_from_vec(M + L + K)
    bu = interleave_arrays(upper_limits, lower_limits)

    @jit
    def compute_cbf_clf_constraints(t: float, x: State) -> Tuple[Array, Array]:
        """Computes CBF and CLF constraints."""
        dynamics_f, dynamics_g, _ = dynamics_func(x)

        # Formulate CBF constraint(s)
        Acbf = jnp.zeros((L, M + K + L))
        bcbf = jnp.zeros((L,))
        if L > 0:
            bf_x = jnp.stack([bf(t, x) for bf in barrier_functions])
            bj_x = jnp.stack([bj(t, x) for bj in barrier_jacobians])
            dbf_t = jnp.stack([bt(t, x) for bt in barrier_partials])

            Acbf = Acbf.at[:, :M].set(-jnp.matmul(bj_x, dynamics_g))
            Acbf = Acbf.at[:, M : M + L].set(-jnp.diag(bf_x))
            bcbf = bcbf.at[:].set(dbf_t + jnp.matmul(bj_x, dynamics_f))
        # # Suppress angular control
        # Acbf = Acbf.at[:, 1].set(0)

        # Formulate CLF constraint(s)
        Aclf = jnp.zeros((K, M + K + L))
        bclf = jnp.zeros((K,))
        if K > 0:
            lf_x = jnp.stack([lf(t, x) for lf in lyapunov_functions])
            lj_x = jnp.stack([lj(t, x) for lj in lyapunov_jacobians])
            dlf_t = jnp.stack([lt(t, x) for lt in lyapunov_partials])
            lc_x = jnp.stack(
                [lc(lf(t, x)) for lc, lf in zip(lyapunov_conditions, lyapunov_functions)]
            )

            Aclf = Aclf.at[:, :M].set(jnp.matmul(lj_x, dynamics_g))
            Aclf = Aclf.at[:, M + L :].set(-jnp.ones((K,)))
            bclf = bclf.at[:].set(-dlf_t - jnp.matmul(lj_x, dynamics_f) + lc_x)

        # Formulate complete set of inequality constraints
        A = jnp.vstack([Au, Acbf, Aclf])
        b = jnp.hstack([bu, bcbf, bclf])

        return A, b

    return compute_cbf_clf_constraints

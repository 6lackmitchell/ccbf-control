import jax.numpy as jnp
from jax import jit, jacfwd, jacrev, Array, grad, jacobian
from typing import Callable, Tuple
from cbfkit.utils.user_types import State


# @jit
def hp(
    x: Array,
    h: Callable[[float, State], Array],
    path: Callable[[float, State], Tuple[Array, Array]],
    dt: float,
) -> Array:
    """Predictive Barrier Function.

    Arguments:
        x: concatenated (current) time and state vector -- [x, t]
        h: constraint function (for evaluating safety at current time)
        path: function to compute a path and control sequence based on the current time and state
        dt: timestep (in sec)

    Returns:
        val: value of predictive CBF

    """
    t = x[-1]
    xbar, _ = path(t, x[:-1])
    tsteps = xbar.shape[0] - 1
    tbar = jnp.linspace(t, t + tsteps * dt, tsteps)

    val = jnp.array([h(tt, xx) for tt, xx in zip(tbar, xbar.T)]).min()

    return val


# @jit
def dhpdx(
    x: Array,
    h: Callable[[float, State], Array],
    path: Callable[[float, State], Tuple[Array, Array]],
    dt: float,
) -> Array:
    """Partial derivative of the predictive control barrier function with respect to the concatentated
    time and state vector.

    Arguments:
        x: concatenated (current) time and state vector -- [x, t]
        h: constraint function (for evaluating safety at current time)
        path: function to compute a path and control sequence based on the current time and state
        dt: timestep (in sec)

    Returns:
        dhdx: gradient of the predictive CBF

    """
    return grad(hp)(x, h, path, dt)[: len(x) - 1]
    return jacobian(hp)(x, h, path, dt)
    return jacrev(hp)(x, h, path, dt)


# @jit
def dhpdt(
    x: Array,
    h: Callable[[float, State], Array],
    path: Callable[[float, State], Tuple[Array, Array]],
    dt: float,
) -> Array:
    """Partial derivative of the predictive control barrier function with respect to the concatentated
    time and state vector.

    Arguments:
        x: concatenated (current) time and state vector -- [x, t]
        h: constraint function (for evaluating safety at current time)
        path: function to compute a path and control sequence based on the current time and state
        dt: timestep (in sec)

    Returns:
        dhdx: gradient of the predictive CBF

    """
    return grad(hp)(x, h, path, dt)[-1]


# @jit
def d2hpdx2(
    x: Array,
    h: Callable[[float, State], Array],
    path: Callable[[float, State], Tuple[Array, Array]],
    dt: float,
) -> Array:
    """Second Partial derivative of the predictive control barrier function with respect to the
    concatentated time and state vector.

    Arguments:
        x: concatenated (current) time and state vector -- [x, t]
        h: constraint function (for evaluating safety at current time)
        path: function to compute a path and control sequence based on the current time and state
        dt: timestep (in sec)

    Returns:
        dhdx: gradient of the predictive CBF

    """
    return jacfwd(jacrev(hp))(x, h, path, dt)

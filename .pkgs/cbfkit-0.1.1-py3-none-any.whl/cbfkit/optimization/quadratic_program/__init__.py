"""#! docstring"""
from .qp_solver_jaxopt import solve

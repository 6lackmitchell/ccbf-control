import platform
import jax.numpy as jnp
import cvxpy as cp
import numpy as np
from typing import Union, Tuple, Any, List, Callable, Dict, Optional
from jax import Array, jit, lax
from cvxpylayers.jax import CvxpyLayer
from jaxopt import OSQP

if platform.system() == "Darwin":
    from kvxopt import matrix, solvers
elif platform.system() == "Linux":
    from cvxopt import matrix, solvers

QP = OSQP(maxiter=10000, tol=1e-2, check_primal_dual_infeasability=True, verbose=True)

###############################################################################
############################ Currently Functional #############################
###############################################################################


def qp_solver(
    H: Array,
    f: Array,
    G: Array,
    h: Array,
    A: Array,
    b: Array,
    lib: str = "cvxopt",
) -> Tuple[Array, int]:
    if lib == "scipy":
        return qp_solver_jax_scipy(H, f, G, h, A, b)
    elif lib == "cvxopt":
        return qp_solver_cvxopt(H, f, G, h, A, b)
    elif lib == "jax":
        return qp_solver_jax(H, f, G, h, A, b)
    else:
        raise ValueError("Argument 'lib' must be one of 'cvxopt', 'scipy', or 'jax'")


def qp_solver_cvxopt(
    H: Array,
    f: Array,
    G: Array,
    h: Array,
    A: Array,
    b: Array,
) -> Tuple[Array, int]:
    """
    Solve a quadratic program using the cvxopt solver.

    Args:
    H: quadratic cost matrix.
    f: linear cost vector.
    A: linear constraint matrix.
    b: linear constraint vector.
    G: quadratic constraint matrix.
    h: quadratic constraint vector.

    Returns:
    sol['x']: Solution to the QP
    """
    # Use the cvxopt library to solve the quadratic program
    P = matrix(np.array(H, dtype=float))
    q = matrix(np.array(f, dtype=float))
    options = {"show_progress": False}

    if np.isnan(G).any():
        return jnp.zeros((G.shape[1],)), False

    # Inequality constraints
    # if G is not None and h is not None:
    G = matrix(np.array(G, dtype=float))
    h = matrix(np.array(h, dtype=float))

    # Equality constraints
    if np.all(A == 0):
        A = None
        b = None
    else:
        if np.linalg.matrix_rank(np.array(A)) < np.array(A).shape[0]:
            raise ValueError("Ill-posed problem: Rank(A) < number of equality constraints")
        A = matrix(np.array(A, dtype=float))
        b = matrix(np.array(b, dtype=float))

    # Check problem conditioning
    check_matrix = np.vstack(list(filter(lambda item: item is not None, [H, G, A])))
    if np.linalg.matrix_rank(check_matrix) < np.array(H).shape[0]:
        raise ValueError("Ill-posed problem: Rank([H; G; A]) < number of decision variables")

    # Compute solution
    sol: Dict[str, Any] = solvers.qp(P, q, G=G, h=h, A=A, b=b, options=options)

    success: bool = sol["status"] == "optimal"  # or (sol["status"] == "unknown")
    if not success:
        sol["x"] = 0 * sol["x"]

    return jnp.array(sol["x"]), success


# @jit
def qp_solver_jax(
    Q: Array,
    c: Array,
    G: Array,
    h: Array,
    A: Array,
    b: Array,
) -> Tuple[Array, int]:
    """
    Solve a quadratic program using the cvxopt solver.

    Args:
    H: quadratic cost matrix.
    f: linear cost vector.
    G: linear inequality constraint matrix.
    h: linear inequality constraint vector.
    A: linear equality constraint matrix.
    b: linear equality constraint vector.

    Returns:
    sol['x']: Solution to the QP
    """
    x0 = jnp.array([-jnp.sign(G[-1, ii]) * h[2 * ii] for ii in range(G.shape[1])])

    G, h, A, b = numerical_scaling(G, h, A, b)

    if jnp.dot(G[-1, :], x0) > h[-1]:
        print("INFEASIBLE")
        return jnp.zeros((Q.shape[1],)), 0

    sol, state = QP.run(params_obj=(Q, c), params_eq=(A, b), params_ineq=(G, h), init_params=x0)

    return sol.primal, state.status


def mpc_solver_cvxpy(
    objective: cp.Expression,
    constraints: List[cp.Expression],
    variables: List[cp.Variable],
    parameters: List[cp.Parameter],
) -> Callable[[Tuple[Array]], Tuple[Array, Array]]:
    """Solves Model Predictive Control problem formulated using Cvxpy according to:

    min j(x[k])
    subject to
    c(x[k], u[k]) >= 0
    d(x[k], u[k]) == 0

    Arguments:
        j: Cvxpy.Objective object
        constraints: List of constraints
        parameters: List of Cvxpy.Parameter objects

    Returns:
        xsol: optimal state trajectory
        usol: optimal control trajectory

    """
    problem = cp.Problem(cp.Minimize(objective), constraints=constraints)
    layer = CvxpyLayer(problem, parameters=parameters, variables=variables)

    def solve_mpc_0(*args: Tuple[Array]) -> Tuple[Array, Array]:
        # def solve_mpc(x0, xd) -> Tuple[Array, Array]:
        x_sol, u_sol = layer(*args)
        # x_sol, u_sol = layer(x0, xd)

        return x_sol, u_sol

    return solve_mpc_0


#! To Do
###############################################################################
############################### In Development ################################
###############################################################################


def qp_solver_jax_scipy(
    Q: Array,
    c: Array,
    G: Union[Array, None] = None,
    h: Union[Array, None] = None,
    A: Union[Array, None] = None,
    b: Union[Array, None] = None,
) -> Tuple[Array, int]:
    """
    Solve a quadratic program using the cvxopt solver.

    Args:
    H: quadratic cost matrix.
    f: linear cost vector.
    A: linear inequality constraint matrix.
    b: linear inequality constraint vector.
    G: linear equality constraint matrix.
    h: linear equality constraint vector.

    Returns:
    sol['x']: Solution to the QP
    """
    if G is None or h is None:
        G = jnp.zeros((1, Q.shape[1]))
        h = jnp.array([0.0])

    if A is None or b is None:
        A = jnp.zeros((1, Q.shape[1]))
        b = jnp.array([0.0])

    sol, status = QP.run(params_obj=(Q, c), params_eq=(A, b), params_ineq=(G, h))

    if int(status[2]) == 1:
        # Success
        return sol[0], True
    else:
        return 0 * sol[0], False


def generate_mpc_to_qp(A: Array, B: Array, Q: Array, R: Array, QN: Array, horizon: int) -> Callable:
    """_summary_

    Args:
        A (Array): _description_
        B (Array): _description_
        Q (Array): _description_
        R (Array): _description_
        QN (Array): _description_
        horizon (int): _description_

    Returns:
        Callable: _description_
    """
    n_states, n_inputs = B.shape

    # Formulating the quadratic cost matrices
    Q1a = jnp.kron(jnp.eye(horizon), Q)
    Q3a = jnp.kron(jnp.eye(horizon), R)
    Q2a = QN

    Q1 = jnp.hstack(
        [Q1a, jnp.zeros((Q1a.shape[0], Q2a.shape[1])), jnp.zeros((Q1a.shape[0], Q3a.shape[1]))]
    )
    Q2 = jnp.hstack(
        [jnp.zeros((Q2a.shape[0], Q1a.shape[1])), Q2a, jnp.zeros((Q2a.shape[0], Q3a.shape[1]))]
    )
    Q3 = jnp.hstack(
        [jnp.zeros((Q3a.shape[0], Q1a.shape[1])), jnp.zeros((Q3a.shape[0], Q2a.shape[1])), Q3a]
    )

    Q_bar = jnp.vstack([Q1, Q2, Q3])
    p_bar = jnp.zeros((Q1a.shape[0] + Q2a.shape[0] + horizon * n_inputs))

    Ax = jnp.kron(jnp.eye(horizon + 1), -jnp.eye(n_states)) + jnp.kron(
        jnp.eye(horizon + 1, k=-1), A
    )
    Bu = jnp.kron(jnp.vstack([jnp.zeros((1, horizon)), jnp.eye(horizon)]), B)

    A_eq = jnp.hstack([Ax, Bu])
    b_eq = jnp.zeros(((1 + horizon) * n_states,))

    # - input and state constraints
    A_ineq = None
    b_ineq = None

    # @jit
    def mpc_to_qp(
        x0: Array,
        xr: Array,
    ) -> Tuple[Array, Array, Union[Array, None], Union[Array, None], Array, Array]:
        """Transforms a Discrete-Time, Linear, Time-Invariant, Model Predictive
        Control problem of the form:

        something

        into a quadratic program of the form:

        something

        Arguments:
            x0: initial state
            A: linear drift matrix
            B: control input matrix
            Q: incremental state cost matrix
            R: incremental control cost matrix
            QN: terminal state cost matrix
            n_steps: length of finite horizon

        Returns:
            H: quadratic cost matrix.
            f: linear cost vector.
            A: linear constraint matrix.
            b: linear constraint vector.
            G: quadratic constraint matrix.
            h: quadratic constraint vector.

        """
        nonlocal p_bar, b_eq

        xr = jnp.hstack([x0.reshape(-1, 1), xr])
        p_bar = p_bar.at[:].set(
            jnp.hstack(
                [
                    -Q1a @ xr[:, :-1].T.flatten(),
                    -Q2a @ xr[:, -1].T.flatten(),
                    jnp.zeros(horizon * n_inputs),
                ]
            )
        )

        # Linear dynamics (equality constraints)
        b_eq = b_eq.at[:].set(jnp.hstack([-x0, jnp.zeros((horizon) * n_states)]))

        # Returning the transformed QP problem
        return (
            Q_bar,
            p_bar,
            A_ineq,
            b_ineq,
            A_eq,
            b_eq,
        )

    return mpc_to_qp


def generate_quadratic_mpc_solver(
    A: Array, B: Array, Q: Array, R: Array, QN: Array, N: int
) -> Callable:
    """_summary_

    Args:
        A (Array): _description_
        B (Array): _description_
        Q (Array): _description_
        R (Array): _description_
        QN (Array): _description_
        N (int): _description_

    Returns:
        Callable: _description_
    """
    n = QN.shape[0]
    m = B.shape[1]
    mpc_to_qp = generate_mpc_to_qp(A, B, Q, R, QN, N)

    # @jit
    def quadratic_mpc_solver(x0: Array, xr: Array) -> Tuple[Array, Array]:
        # Convert Discrete-Time, LTI MPC problem into QP and solve
        H, f, A, b, G, h = mpc_to_qp(x0, xr)
        sol, status = qp_solver(H, f, A, b, G, h, lib="jax")

        # Extract optimal state and control trajectories
        sol = jnp.array(sol).flatten()
        x_opt = sol[: (N + 1) * n].reshape((N + 1, n)).T
        u_opt = sol[(N + 1) * n :].reshape((N, m)).T

        return x_opt, u_opt

    return quadratic_mpc_solver


def numerical_scaling(G: Array, h: Array, A: Array, b: Array) -> Tuple[Array, Array, Array, Array]:
    """Normalizes equality and inequality constraint matrices for better numerical performance.

    Args:
        G (Array): inequality constraint matrix
        h (Array): inequality constraint vector
        A (Array): equality constraint matrix
        b (Array): equality constraint vector

    Returns:
        Tuple[Array, Array, Array, Array]: scaled values of G, h, A, b
    """
    # Numerical Scaling
    eps = 0.1
    Gh_sf = 1 / jnp.max(jnp.array([eps, jnp.max(jnp.abs(G)), jnp.max(jnp.abs(h))]))
    Ab_sf = 1 / jnp.max(jnp.array([eps, jnp.max(jnp.abs(A)), jnp.max(jnp.abs(b))]))
    G = G * Gh_sf
    h = h * Gh_sf
    A = A * Ab_sf
    b = b * Ab_sf

    return G, h, A, b


if __name__ == "__main__":
    n = 4
    m = 2
    n_steps = 100
    dt = 0.05

    # Initialize parameters: initial state
    x0 = cp.Parameter((n,))
    xd = cp.Parameter((n, n_steps))
    parameters = [x0, xd]

    # Initialize variables: state and control trajectories
    x = cp.Variable((n, n_steps + 1))
    u = cp.Variable((m, n_steps))
    variables = [x, u]

    # Initialize cost and constraints
    objective = 0
    constraints = []

    # Linear Dynamics
    Bk = jnp.zeros((n, m))
    Bk = Bk.at[2, 0].set(1)
    Bk = Bk.at[3, 1].set(1)
    A = jnp.array(
        [
            [1, 0, dt, 0],
            [0, 1, 0, dt],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
        ]
    )

    B = (
        jnp.array(
            [
                [dt, 0, 0.5 * dt**2, 0],
                [0, dt, 0, 0.5 * dt**2],
                [0, 0, dt, 0],
                [0, 0, 0, dt],
            ]
        )
        @ Bk
    )

    # Incremental state (Q), control (R), and terminal state (P) costs
    Q = jnp.eye(n, dtype=float)
    R = jnp.eye(m, dtype=float)
    R = jnp.array([[1000, 0], [0, 1]])

    # Calculate incremental costs
    z = x[:, 1 : n_steps + 1] - xd[:, :]
    objective += 0.5 * cp.sum([cp.sum_squares(Q @ z[:, s]) for s in range(n_steps)])
    objective += 0.5 * cp.sum([cp.sum_squares(R @ u[:, s]) for s in range(n_steps)])

    # Calculate dynamics constraints
    dynamics_constraint = [x[:, 1 : n_steps + 1] == A @ x[:, :n_steps] + B @ u]

    # Add all constraints
    constraints += dynamics_constraint

    # Add terminal and initial constraints
    constraints += [x[:, 0] == x0]

    solve = mpc_solver_cvxpy(
        objective=objective, constraints=constraints, variables=variables, parameters=parameters
    )

    initial_state = jnp.array([1, 1, 0, 0], dtype=float)
    desired_state = jnp.zeros(xd.shape)

    xbar, ubar = solve(initial_state, desired_state)
    print(xbar[:, -1], ubar[:, -1])

    ###########################################################################

    # Initialize parameters: initial state
    x0 = initial_state
    xd = desired_state

    # Initialize variables: state and control trajectories
    x = cp.Variable((n, n_steps + 1))
    u = cp.Variable((m, n_steps))

    # Initialize cost and constraints
    cost = 0
    constraints = []

    # Calculate incremental costs
    z = x[:, 1 : n_steps + 1] - xd[:, :]
    cost += 0.5 * cp.sum([cp.quad_form(z[:, s], Q) for s in range(n_steps)])
    cost += 0.5 * cp.sum([cp.quad_form(u[:, s], R) for s in range(n_steps)])

    # Calculate dynamics constraints
    dynamics_constraint = [x[:, 1 : n_steps + 1] == A @ x[:, :n_steps] + B @ u]

    # Add all constraints
    constraints += dynamics_constraint

    # Add terminal and initial constraints
    constraints += [x[:, 0] == x0]

    problem = cp.Problem(cp.Minimize(cost), constraints=constraints)
    problem.solve(verbose=False)
    print(x[:, -1].value, u[:, -1].value)

    ###########################################################################

    # x_opt, u_opt = solve_mpc(x0, xd, A, B, Q, R, Q, n_steps)
    # print(x_opt[:, -1], u_opt[:, -1])

    # x_opt, u_opt = solve_mpc(x0, xd, A, B, Q, R, Q, n_steps)
    # print(x_opt[:, -1], u_opt[:, -1])

    # x_opt, u_opt = solve_mpc(x0, xd, A, B, Q, R, Q, n_steps)
    # print(x_opt[-1, :], u_opt[-1, :])
